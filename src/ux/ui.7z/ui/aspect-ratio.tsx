"use client";

import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";
// need to add smth because vercel git integration is not working

const AspectRatio = AspectRatioPrimitive.Root;

export { AspectRatio };
